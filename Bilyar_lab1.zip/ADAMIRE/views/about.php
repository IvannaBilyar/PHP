<section class="podcast" id="about">
		<div class="container">
			<div class="podcast-row">
				<div class="podcast-img-wrapper">
					<img src="./img/leaf-wall-office-space.jpg" alt="" class="podcast-img" />

				</div>

				<div class="podcast-content">
					<h3 class="podcast-content-subtitle">
						Hi, we are an ADAMIRE team!
					</h3>

					<div class="podcast-content-text">
						<p>
							Everyone experiences it, and in different ways. Let Alivio guide
							you, in a personalized journal experience, to overcome your
							stress.
						</p>
					</div>
					<!-- <div class="podcast-content-btn">
						<a href="#" class="btn btn-big">Explore</a>
					</div> -->
				</div>
			</div>
		</div>
	</section>