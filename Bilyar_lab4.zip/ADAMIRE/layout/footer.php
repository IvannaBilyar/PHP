<footer>
		<section class="footer">
			<div class="box-container">

				<div class="box">
					<h4>quick links</h4>
					<a href="#home">home</a>
					<a href="#about">about</a>
					<a href="#solutions">solutions</a>
					<a href="#photos">photos</a>
					<a href="#podcast">podcasts</a>
				</div>

				<div class="box">
					<h4>extra links</h4>
					<a href="#">FAQs</a>
					<a href="#">help</a>
					<a href="#">have any question</a>
					<a href="#">privacy policy</a>
				</div>

				<div class="box">
					<h4>contact info</h4>
					<a href="#"> <i class="fas fa-phone"></i> +380-965-34-31-11 </a>
					<a href="#"> <i class="fas fa-envelope"></i> ivankabilyar@gmail.com </a>
					<a href="#"> <i class="fas fa-map-marker-alt"></i> Ukraine, Chernivtsi </a>
				</div>

				<div class="box">
					<h4>follow us</h4>
					<a href="#"> <i class="fab fa-twitter"></i> twitter </a>
					<a href="#"> <i class="fab fa-instagram"></i> instagram </a>
					<a href="#"> <i class="fab fa-pinterest"></i>pinterest</a>
				</div>

			</div>

			<h5 class="line"> created by <span> Ivanna Bilyar </span> | all rights reserved! </h5>

		</section>
	</footer>

	<script src="./js/main.js"></script>
	<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
	<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>