<section class="podcast">
            <div class="container">
                <div class="registration-content">
                    <h3 class="registration-success-subtitle">
                        Your registration was successful!!!
                        <br></h3>
                    <a href="index.php?action=main" class="button">Home</a>

                </div>
            </div>
</section>