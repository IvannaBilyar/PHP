<?php
if(!empty($_POST)){ 
	$flag = true;
	if(isset($_POST["login"]) && (preg_match("/[!,.@#$%^&*()+=~?`><�;:]/",$_POST["login"]) || strlen($_POST["login"]) < 4)){
	?>
		<div class='error'>
			<p>Please, enter a valid login!
			The login can contain only Latin and Cyrillic letters 
			(uppercase and lowercase), numbers, underscores, and hyphens. 
			The length of the login must be at least 4 characters!
			</p>
		</div>
	<?php
		$flag = false;
	}

	if(isset($_POST["email"]) && !preg_match("/^(?:[a-z0-9]+(?:[-_.]?[a-z0-9]+)?@[a-z0-9_.-]+(?:\.?[a-z0-9]+)?\.[a-z]{2,5})$/i",$_POST["email"])){
        ?>
            <div class='error'>
                <p>Please, enter a valid email address!</p>
            </div>
        <?php  
        $flag=false;
        }

	if(isset($_POST["password"]) && (!preg_match("/[A-Z�-�]/",$_POST["password"]) || !preg_match("/[a-z�-�]/",$_POST["password"]) || !preg_match("/\d/",$_POST["password"]) || strlen($_POST["password"]) < 7)){
		?>
			<div class='error'>
				<p> The password must contain lowercase and uppercase letters, 
					as well as numbers! 
					The password must also be at least 7 characters long!
				</p>
			</div>
		<?php
			$flag = false;
		}

		if(isset($_POST["repeatpassword"]) && ($_POST["password"] != $_POST["repeatpassword"])){
		?>
			<div class='error'>
				<p>Passwords don't match!</p>
			</div>
		<?php
			$flag=false;
		}

		
		if(isset($_POST["webpage"]) && !empty($_POST["webpage"])){
			$webpage = $_POST["webpage"];
			if(strlen($webpage) > 255){
				?>
					<div class='error'>
						<p>The website URL cannot exceed 255 characters!!!</p>
					</div>
				<?php
				$flag = false;
			}
			elseif(!preg_match("/^(https?:\/\/)?([\w-]+\.)*[\w-]+(\.[a-z]{2,})((\?\w+=\w+)?(&\w+=\w+)*)?$/i", $webpage)){
				?>
					<div class='error'>
						<p>Enter a valid website URL!!!</p>
					</div>
				<?php
				$flag = false;
			}
		}
		


		if($flag){
            header ('Location: index.php?action=registration_successful'); 
            exit(); 
        }
}
?> 



<div class="form_wrapper">
		<div class="form_container">
			<div class="title_container">
				<h2>Sign up</h2>
			</div>
			<div class="row clearfix">

					<form action="index.php?action=registration" method="POST">
						<label> Login <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
							<input type="text" name="login" placeholder="Enter your login" />
						</div>
						<label> Email <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-envelope"></i></span>
							<input type="email" name="email" placeholder="Enter your email" required />
							
						</div>
						<label> Password <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
							<input type="password" name="password" placeholder="Create your password" required />
							
						</div>
						<label> Confirm Password <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
							<input type="password" name="repeatpassword" placeholder="Confirm your password" required />
							
						</div>
						<label> My webpage </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
							<input type="text" name="webpage" placeholder="" />
						</div>
						
						<input class="button" type="submit" name="submit" value="Register" />
					</form>
			</div>
		</div>
</div>
