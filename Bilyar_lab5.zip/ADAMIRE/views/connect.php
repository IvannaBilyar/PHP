<?php
$mysql = new mysqli('localhost', 'root', '', 'adamire', 3307);
if($mysql->connect_errno != 0)
{
    die($mysql->connect_error);
}