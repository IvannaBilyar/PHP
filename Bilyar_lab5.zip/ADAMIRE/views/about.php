<section class="podcast" id="about">
		<div class="container">
			<div class="podcast-row">
				<div class="podcast-img-wrapper">
					<img src="./img/leaf-wall-office-space.jpg" alt="" class="podcast-img" />

				</div>

				<div class="podcast-content">
					<h3 class="podcast-content-subtitle">
						Hi, welcome to our blog!
					</h3>

					<div class="podcast-content-text">
						<p>
							We are an ADAMIRE team and we are dedicated to helping our visitors 
							overcome stress through a holistic approach that addresses the physical, 
							emotional, and mental aspects of their well-being.
							On our website, you can find useful information 
							and advice that will help you to feel good about yourself. 
							<br>
							Love and take care of yourself, because you are the best!
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>