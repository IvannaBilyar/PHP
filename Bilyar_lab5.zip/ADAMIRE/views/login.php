<?php
$login = $_POST['login'];
$password = $_POST['password'];

if(isset($_POST['log_in']))
{
	$query = "SELECT * FROM `users` WHERE `login`='$login'";
	$result = $mysql->query($query)->fetch_assoc();
	if($mysql->errno != 0)
    {
        die($mysql->error);
    }

    if($result && password_verify($password, $result["password"]))
    {
        $_SESSION["user"] = ["id"=>$result["id"], "login"=>$result["login"],"admin"=>$result["admin"]];
        header ('Location: index.php?action=main');
    }
    else
    {
		?>
		<div class='error'>
			<p>Please, enter a valid login or password!!!</p>
		</div>
		<?php
    }
    
	$mysql->close();
    
}

?>

<div class="form_wrapper_log">
		<div class="form_container">
			<div class="title_container">
				<h2>Sign in</h2>
			</div>
			<div class="row clearfix">
				<div class="">
                    <form action="index.php?action=login" method="POST">
                        <label> Login <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
							<input type="text" name="login" placeholder="Enter your login" />
						</div>
						
						<label> Password <span> * </span> </label>
						<div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
							<input type="password" name="password" placeholder="Enter your password" required />
						</div>
						
						<input class="button" type="submit" name="log_in" value="Log in"/>
					</form>
				</div>
			</div>
		</div>
	</div>
