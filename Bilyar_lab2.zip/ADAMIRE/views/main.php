<section class="home" id="home">
		<div class="container">
			<div class="home-content">
				<h1 class="home-heading">Be happy, Enjoy your life</h1>
				<div class="home-text">
					<p>
						These days it's hard not to get overwhelmed once in a while.
						<br>
						Between juggling work, family, and other commitments, you can become too stressed out and
						busy...
						<br>
						So allow yourslef to relax from time to time!
					</p>
				</div>
				<div class="home-btn">
					<a href="#" class="btn btn-big">Find Your Way</a>
				</div>
			</div>
		</div>
		<div class="home-bg-img">
			<img src="./img/person-sitting-at-a-desk-working.jpg" alt="Background cover" />
		</div>
	</section>

	<section class="how-it-works" id="solutions">
		<div class="container">
			<div class="how-it-works-header">
				<div class="how-it-works-header-head">
					<h2 class="how-it-works-subtitle">
						Understand & Release stress in 3 steps
					</h2>
				</div>
			</div>

			<div class="how-it-works-steps">
				<div class="step">
					<h4 class="step-heading" data-number="01">Self-Talk</h4>

					<div class="step-text">
						<p>
							If things are bothering you, talking about them can help lower your stress.
							Answer a quick survey about how you express yourself and what
							causes you stress! 
							<br>
							But remember self-talk must be positive!
						</p>
					</div>

					<div class="step-img-wrapper">
						<img class="step-img" src="./img/step1.jpg" alt="Step Img" />
					</div>
				</div>
				<!-- //step -->

				<div class="step">
					<h4 class="step-heading" data-number="02">Relax Your Muscles</h4>

					<div class="step-text">
						<p>
							Working out regularly is one of the best ways to relax your body and mind.
							<br>
							Plus, exercises will improve your mood!
						</p>
					</div>

					<div class="step-img-wrapper">
						<img class="step-img" src="./img/step3.jpg" alt="Step Img" />
					</div>
				</div>
				<!-- //step -->

				<div class="step">
					<h4 class="step-heading" data-number="03">Take A Break</h4>

					<div class="step-text">
						<p>
							Modern life is so busy, and sometimes you just need to slow down and chill out.
							Spending your free time with yourself in nature, listening to your favoutite music..
							<br>
							Try to do something that makes you feel good and it will help relieve your stress!
						</p>
					</div>

					<div class="step-img-wrapper">
						<img class="step-img" src="./img/step-02.jpg" alt="Step Img" />
					</div>
				</div>
				<!-- //step -->
			</div>
		</div>
	</section>

	<section class="story" id="photos">
		<div class="container container-wide">
			<div class="story-row">

				<div class="story-content">
					<h2 class="story-heading">Find beauty in simple things</h2>
					<div class="story-text">
						<p>Live, create, dance, sing, dream, enjoy! 
							<br>
							Let yourself feel the taste of real life!</p>
					</div>
					<div class="story-btn">
						<a href="#" class="btn btn-big">Let's get started</a>
					</div>
				</div>

				<div class="container">
					<div class="slider-wrapper">
						<div class="slider">
							<img id="slide-1" src="./img/bed-with-book-and-flowers.jpg" alt="Slide img">
							<img id="slide-2" src="./img/seaside-ocean-pools.jpg" alt="Slide img">
							<img id="slide-3" src="./img/bikes-take-the-turn.jpg" alt="Slide img">
							<img id="slide-4" src="./img/woman-sits-on-the-side-of-a-hill-above-water.jpg"alt="Slide img">
							<img id="slide-5" src="./img/live-concert-drums.jpg" alt="Slide img">
							<img id="slide-6" src="./img/father-helps-toddler-decorate-christmas-tree.jpg" alt="Slide img">
							<img id="slide-7" src="./img/art-supplies.jpg" alt="Slide img">
						</div>
						<div class="slider-nav">
							<a href="#slide-1"></a>
							<a href="#slide-2"></a>
							<a href="#slide-3"></a>
							<a href="#slide-4"></a>
							<a href="#slide-5"></a>
							<a href="#slide-6"></a>
							<a href="#slide-7"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="podcast" id="podcast">
		<div class="container">
			<div class="podcast-row">
				<div class="podcast-img-wrapper">
					<img src="./img/woman-in-white-dress-outside.jpg" alt="" class="podcast-img" />

					<div class="podcast-card">
						<div class="card">
							<h3 class="card-title">Best Podcasts for You</h3>

							<div class="card-contents">
								<ul>
									<li><span>"The Stressless Life"</span> by Dr. Jenny Yip</li>
									<li><span>"The Mindful Minute"</span> by Meryl Arnett</li>
									<li><span>"The Art of Charm"</span> by AJ Harbinger and Johnny Dzubak</li>
								</ul>
							</div>
						</div>
					</div>
				</div>

				<div class="podcast-content">
					<h3 class="podcast-content-subtitle">
						Lessons of Life: Things
						I've Learned, Moments I Cherish.
					</h3>

					<div class="podcast-content-text">
						<p>
							We have selected a great set of podcasts for you that will help you to put aside unnecessary
							thoughts
							and plunge into the world of peace of mind.
						</p>
					</div>
					<div class="podcast-content-btn">
						<a href="https://open.spotify.com/playlist/6hS36f0TO2K7mqRJRT5mYV" class="btn btn-big">Explore</a>
					</div>
				</div>
			</div>
		</div>
	</section>

	<button onclick="topFunction()" id="myBtn" type="Go to top"><i class="fas fa-chevron-up"></i></button>
