<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>A D A M I R E</title>
	<link rel="stylesheet" href="./css/style.css" />
	<!-- Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link
		href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Nunito:ital,wght@0,500;1,400&display=swap"
		rel="stylesheet">
	<script src="https://kit.fontawesome.com/3b0544fe2b.js" crossorigin="anonymous"></script>
</head>

<body>
	<header class="header">
		<div class="container">
			<div class="header-row">
				<div class="header-logo">adamire</div>
				<nav class="nav-item">
					<ul>
						<li><a href="./index.php?action=main">Home</a></li>
						<li><a href="./index.php?action=about">About</a></li>
						<li><a href="#solutions">Solutions</a></li>
						<li><a href="#photos">Photos</a></li>
						<li><a href="#podcast">Podcasts</a></li>
					</ul>
				</nav>
				<div class="header-login">
					<a class="header-login-link" href="#">Sign in</a>
					<a href="index.php?action=registration" class="btn">Sign up</a>
				</div>
			</div>
		</div>
	</header>